1) Download the project from the site and paste it in htdocs.
2) import database file from database folder name cubexo.
3) change the server name, user, password of connection.php in PHP folder.
4) now run index.html file.