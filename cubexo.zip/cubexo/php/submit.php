<?php 
	 
     include('connection.php');
     $name = $_POST['name'];
     $address = $_POST['address'];
     $email= $_POST['email'];
     $mobile= $_POST['mobile'];
    $query = "INSERT INTO cubexo (name, phone, email, address) VALUES ('$name','$mobile','$email','$address')";
    $result = mysqli_query($conn, $query);
    if($result){
    	header("Location:success.html");
    }
    else {
    	echo "You not got Register please try again";
    	header("Location:../index.html");
    }
?>